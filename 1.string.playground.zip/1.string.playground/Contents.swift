import UIKit

var str0 = "Hello, playground. nice meeting you"
print(str0)
//콘솔로 보고싶으면 쉬프트 + 엔터

// 두줄로 만들고 싶다. 두줄로 만들고 싶은 문장 앞에 \n 입력.

var str = "승환, \n안녕"

print(str)


// 세줄짜리 혹은 그 이상문자열.
var str1 = """
승환아
안녕
"뭐해?"
"""
print(str1)

// 비어있는지 확인하는 2가지 방법

var emptyString = ""
var anotherEmptyString = String()

if emptyString.isEmpty {
    print("Nothing to see here")
}

// 문자열은 더하면 하나의 문자열로 합쳐진다
let string1 = "hello"
let string2 = " there"

var welcome = string1 + string2
print(welcome)

//

var instruction = "look over"
instruction += string2

print(instruction)

//문자 스펠링 수 count 세는 것
print(instruction.count)
